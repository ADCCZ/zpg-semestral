﻿using OpenTK.Graphics.OpenGL;
using OpenTK.Mathematics;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Reflection;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace semestral
{
    /// <summary>
    /// Jednoduchý model obsahující seznam vrcholů
    /// </summary>
    public class Model : IDisposable
    {
        public Shader Shader { get; set; }
        public Material Material { get; set; }
        public Vector3 position { get; set; }
        public AABB CollisionBox { get; set; }

        int vbo;
        int ibo;
        int vao;

        int triangles;

        public Vector3 rotation = Vector3.Zero;
        public float rotationSpeed = 0f;

        public Model(Vertex[] vertices, int[] indices, Material material)
        {
            triangles = indices.Length / 3;
            Material = material;

            // vytvoření a připojení VAO
            GL.GenVertexArrays(1, out vao);
            GL.BindVertexArray(vao);

            // Vytvoření a připojení VBO
            vbo = GL.GenBuffer();
            GL.BindBuffer(BufferTarget.ArrayBuffer, vbo);
            GL.BufferData(BufferTarget.ArrayBuffer, vertices.Length * Vertex.SizeOf(), vertices, BufferUsageHint.StaticDraw);

            // vytvoření a připojení IBO
            ibo = GL.GenBuffer();
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, ibo);
            GL.BufferData(BufferTarget.ElementArrayBuffer, indices.Length * sizeof(int), indices, BufferUsageHint.StaticDraw);

            // namapování pointerů na lokace v shaderu
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, Vertex.SizeOf(), IntPtr.Zero);
            GL.EnableVertexAttribArray(0);
            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, Vertex.SizeOf(), (IntPtr)3 * sizeof(float));
            GL.EnableVertexAttribArray(1);

            GL.BindVertexArray(0);
        }

        /// <summary>
        /// Vykreslení modelu
        /// </summary>
        public void Draw(Camera camera, Light light)
        {
            Matrix4 rotationMatrix = Matrix4.CreateRotationX(rotation.X) *
                                     Matrix4.CreateRotationY(rotation.Y) *
                                     Matrix4.CreateRotationZ(rotation.Z);
            Matrix4 translationMatrix = Matrix4.CreateTranslation(position);
            Matrix4 modelMatrix = rotationMatrix * translationMatrix;

            Shader.Use();
            Shader.SetUniform("projection", camera.Projection);
            Shader.SetUniform("view", camera.View);
            Shader.SetUniform("model", modelMatrix);
            Shader.SetUniform("cameraPosWorld", camera.position);

            Shader.SetUniform("lightPosWorld", light.position.Xyz);
            Shader.SetUniform("lightDirWorld", -light.direction);

            Shader.SetUniform("lightColor", light.color);
            Shader.SetUniform("lightIntensity", light.intensity);
            Shader.SetUniform("lightOn", 1);
            Shader.SetUniform("cutOff", (float)Math.Cos(2 * Math.PI / 180));

            Material.SetUniforms(Shader);

            GL.BindVertexArray(vao);
            GL.PolygonMode(TriangleFace.FrontAndBack, PolygonMode.Fill);
            GL.DrawElements(PrimitiveType.Triangles, 3 * triangles, DrawElementsType.UnsignedInt, IntPtr.Zero);
            GL.BindVertexArray(0);
        }

        #region Dispose - uvolnění paměti
        bool disposed = false;
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // případně spravované čištění
                }

                disposed = true;
            }
        }

        ~Model() => Dispose(false);
        #endregion
    }
}
