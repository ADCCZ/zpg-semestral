﻿using System.Drawing.Printing;
using OpenTK.Graphics.OpenGL;
using OpenTK.Mathematics;
using OpenTK.Windowing.Common;
using OpenTK.Windowing.Desktop;
using OpenTK.Windowing.GraphicsLibraryFramework;

namespace semestral;

public class Program : GameWindow
{
    public static void Main() => new Program().Run();

    Viewport mainViewport;
    Camera mainCamera;
    Light flashlight;
    World world;

    const float playerHeight = 1.7f;
    const float lightHeight = 2.05f;
    const float weight = 80.0f; // kg

    const float depressionAngle = (float)(-2 * Math.PI / 180);

    private int frameCount = 0;
    private double elapsedTime = 0.0;
    private double currentFPS = 0.0;

    public Program() : base(
        new GameWindowSettings
        {
            //UpdateFrequency = 60.0, // logika běží max. 60x za sekundu
        },
        new NativeWindowSettings
        {
            ClientSize = new Vector2i(1920, 1080),
            Title = "Semestrální práce ZPG"
        })
    { }


    protected override void OnLoad()
    {
        base.OnLoad();
        GL.Enable(EnableCap.DebugOutput);
        GL.Enable(EnableCap.DebugOutputSynchronous);
        GL.DebugMessageCallback(DebugCallback, IntPtr.Zero);
        GL.Enable(EnableCap.DepthTest);

        GL.ClearColor(0.3f, 0.3f, 0.3f, 1.0f);

        CursorState = CursorState.Grabbed;

        mainViewport = new Viewport()
        {
            Left = 0,
            Top = 0,
            Width = 1,
            Height = 1,
            window = this
        };

        world = new World("Assets/mapa1.txt");

        InitPlayer();
    }

    private void InitPlayer()
    {
        mainCamera = new Camera(mainViewport);
        if (world.StartPos != null)
        {
            mainCamera.position = new Vector3(world.StartPos.X, playerHeight, world.StartPos.Z);
        }
        else
        {
            mainCamera.position = new Vector3(0f, playerHeight, 0f);
        }

        flashlight = new Light(new Vector3(mainCamera.position.X, mainCamera.position.Y + (lightHeight - playerHeight), mainCamera.position.Z), true);
    }


    private static void DebugCallback(DebugSource source, DebugType type, int id, DebugSeverity severity, int length, IntPtr message, IntPtr userParam)
    {
        string msg = System.Runtime.InteropServices.Marshal.PtrToStringAnsi(message, length);
        Console.WriteLine($"OpenGL Debug Message: {msg}\nSource: {source}, Type: {type}, Severity: {severity}, ID: {id}");
    }

    protected override void OnResize(ResizeEventArgs e)
    {
        base.OnResize(e);
        mainViewport.Set();
    }

    protected override void OnRenderFrame(FrameEventArgs args)
    {
        base.OnRenderFrame(args);
        GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
        world.RenderAllModels(mainCamera, flashlight);
        SwapBuffers();
    }

    Vector2 mouseDelta;

    protected override void OnMouseMove(MouseMoveEventArgs e)
    {
        mouseDelta += new Vector2(e.DeltaX, e.DeltaY);
    }

    protected override void OnUpdateFrame(FrameEventArgs args)
    {
        Vector3 moveDir = Vector3.Zero;

        Vector3 forward = new Vector3(mainCamera.GetDirection().X, 0, mainCamera.GetDirection().Z).Normalized();
        Vector3 right = Vector3.Cross(forward, Vector3.UnitY).Normalized();

        if (KeyboardState.IsKeyDown(OpenTK.Windowing.GraphicsLibraryFramework.Keys.W)) moveDir += forward;
        if (KeyboardState.IsKeyDown(OpenTK.Windowing.GraphicsLibraryFramework.Keys.S)) moveDir -= forward;
        if (KeyboardState.IsKeyDown(OpenTK.Windowing.GraphicsLibraryFramework.Keys.A)) moveDir -= right;
        if (KeyboardState.IsKeyDown(OpenTK.Windowing.GraphicsLibraryFramework.Keys.D)) moveDir += right;
        //if (KeyboardState.IsKeyDown(OpenTK.Windowing.GraphicsLibraryFramework.Keys.E)) ;

        if (moveDir.LengthSquared > 0.0001)
        {
            mainCamera.TryMove(moveDir.Normalized(), (float)args.Time, world.worldModels);
        }

        world.UpdateAllModels((float)args.Time);

        // Baterka
        flashlight.position = new Vector4(
            mainCamera.position.X,
            mainCamera.position.Y + (lightHeight - playerHeight),
            mainCamera.position.Z,
            1.0f
        );

        if (mouseDelta.LengthSquared > 0.00001)
        {
            mainCamera.RotateX(mouseDelta.Y * (float)args.Time);
            mainCamera.RotateY(mouseDelta.X * (float)args.Time);
            mouseDelta = Vector2.Zero;

            Quaternion depression = Quaternion.FromAxisAngle(Vector3.Normalize(Vector3.Cross(mainCamera.GetDirection(), Vector3.UnitY)), depressionAngle);
            flashlight.direction = Vector3.Normalize(Vector3.Transform(mainCamera.GetDirection(), depression));
        }

        frameCount++;
        elapsedTime += args.Time;

        if (elapsedTime >= 1.0)
        {
            currentFPS = frameCount / elapsedTime;
            Title = $"Semestrálka - FPS: {currentFPS:F1}";
            frameCount = 0;
            elapsedTime = 0.0;
        }
    }



}
