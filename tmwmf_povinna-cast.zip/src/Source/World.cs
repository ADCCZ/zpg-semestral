﻿using OpenTK.Mathematics;
using System;
using System.Collections.Generic;
using System.IO;

using semestral;

public class World
{
    public List<Model> worldModels { get; private set; }
    public List<Light> worldLights { get; private set; }
    public Vector3 StartPos { get; private set; }
    private WorldElement[,] worldData;

    private string objPath = "Assets/";
    private string shaderPath = "Shaders/";

    Material wallMaterial = new Material(new Vector3(0.2f, 0.2f, 0.6f), new Vector3(0.2f), 5f);
    Material doorMaterial = new Material(new Vector3(0.45f, 0.25f, 0.1f), new Vector3(0.1f), 10f);
    Material lampMaterial = new Material(new Vector3(0.8f, 0.8f, 0.7f), new Vector3(0.9f), 64f);
    Material floorMaterial = new Material(new Vector3(0.4f, 0.4f, 0.4f), new Vector3(0.6f), 32f);
    Material ceilMaterial = new Material(new Vector3(0.4f, 0.6f, 0.4f), new Vector3(0.1f), 5f);
    Material invisibleMaterial = new Material(Vector3.Zero, Vector3.Zero, 0f);
    Material collectibleMaterial = new Material(new Vector3(1.0f, 0.84f, 0.0f), new Vector3(1.0f), 64f);
    Material objectMaterial = new Material(new Vector3(0.6f, 1.0f, 0.9f), new Vector3(1.0f), 128f);
    //Material enemyMaterial = new Material(new Vector3(0.8f, 0.1f, 0.1f), new Vector3(0.5f, 0.05f, 0.05f), 64f);

    public World(string filePath)
    {
        worldModels = new List<Model>();
        worldLights = new List<Light>();

        LoadMap(filePath);
    }

    private void LoadMap(string filePath)
    {
        if (!File.Exists(filePath))
            throw new FileNotFoundException("Map file not found", filePath);

        string[] lines = File.ReadAllLines(filePath);

        var dimensions = lines[0].Split('x');
        int width = int.Parse(dimensions[0]);
        int height = int.Parse(dimensions[1]);

        worldData = new WorldElement[height, width];

        for (int row = 0; row < height; row++)
        {
            for (int col = 0; col < width; col++)
            {
                char tile = lines[row + 1][col];
                worldData[row, col] = GetWorldElementFromChar(tile);
            }
        }

        GenerateWorldModels();
    }

    private WorldElement GetWorldElementFromChar(char tile)
    {
        if (tile == '@') return WorldElement.StartPosition;
        if (tile == ' ' || (tile >= 'a' && tile <= 'n')) return WorldElement.Empty;
        if (tile >= 'o' && tile <= 'z') return WorldElement.Wall;
        if (tile == '*' || tile == '^' || tile == '!') return WorldElement.Light;
        if (tile >= 'A' && tile <= 'G') return WorldElement.Door;
        if (tile >= 'H' && tile <= 'N') return WorldElement.Object;
        if (tile >= 'O' && tile <= 'R') return WorldElement.Enemy;
        if (tile >= 'T' && tile <= 'Z') return WorldElement.Collectible;
        return WorldElement.Custom;
    }

    private void GenerateWorldModels()
    {
        int height = worldData.GetLength(0);
        int width = worldData.GetLength(1);

        for (int row = 0; row < height; row++)
        {
            for (int col = 0; col < width; col++)
            {
                WorldElement element = worldData[row, col];
                Vector3 position = new Vector3(col * 2, 0f, row * 2);
                worldModels.Add(CreateModel(position + new Vector3(0f, 3f, 0f), "plane.obj", ceilMaterial, false, 0, 0));
                worldModels.Add(CreateModel(position + new Vector3(0f, 0f, 0f), "plane_clear.obj", floorMaterial, false, 0, 0));

                bool isEdge = row == 0 || row == height - 1 || col == 0 || col == width - 1;

                if (element == WorldElement.StartPosition)
                {
                    StartPos = position;
                }
                else
                {
                    switch (element)
                    {
                        case WorldElement.Wall:
                            Console.WriteLine($"WALL at {position}");
                            worldModels.Add(CreateModel(position, "wall.obj", wallMaterial, true, 0, 0));
                            break;

                        case WorldElement.Light:
                            (Model lightModel, Light light) = CreateLightModel(position);
                            worldModels.Add(lightModel);
                            worldLights.Add(light);
                            break;

                        case WorldElement.Door:
                            Console.WriteLine($"DOOR at {position}");
                            worldModels.Add(CreateModel(position, "wall.obj", doorMaterial, false, 0, 0));
                            break;

                        case WorldElement.Collectible:
                            Console.WriteLine($"COLLECTIBLE at {position}");
                            worldModels.Add(CreateModel(position + new Vector3(0, 1f, 0), "cube.obj", collectibleMaterial, false, 0, 2f));
                            break;

                        case WorldElement.Object:
                            Console.WriteLine($"OBJECT at {position}");
                            worldModels.Add(CreateModel(position + new Vector3(0, 0f, 0), "cow.obj", objectMaterial, true, 0, 1.5f));
                            break;

                        /*case WorldElement.Enemy:
                            Console.WriteLine($"ENEMY at {position}");
                            worldModels.Add(CreateModel(position + new Vector3(0, 0f, 0), "npc.obj", enemyMaterial, true, 0, 0f));
                            break;*/
                    }
                }

                if (isEdge && element == WorldElement.Empty)
                {
                    worldModels.Add(CreateModel(position, "wall.obj", invisibleMaterial, true, 0, 0));
                }
            }
        }
    }

    private Model CreateModel(Vector3 position, string fileName, Material material, bool hasCollision, float yRotation, float rotationSpeed)
    {
        string path = Path.Combine(objPath, fileName);
        (Vertex[] vertices, int[] indices) = SimpleObj.LoadObj(path);
        Model model = new Model(vertices, indices, material);
        model.Shader = new Shader(Path.Combine(shaderPath, "basic.vert"), Path.Combine(shaderPath, "basic.frag"));
        model.position = position;
        model.rotation = new Vector3(0, yRotation, 0);
        model.rotationSpeed = rotationSpeed;

        if (hasCollision)
        {
            Vector3 min = model.position - new Vector3(1f, 0f, 1f);
            Vector3 max = model.position + new Vector3(1f, 3f, 1f);
            model.CollisionBox = new AABB(min, max);
        }

        return model;
    }

    private (Model, Light) CreateLightModel(Vector3 position)
    {
        Model lightModel = CreateModel(position + new Vector3(0f, 3f, 0f), "lamp.obj", lampMaterial, false, 0, 0);
        Light light = new Light(lightModel.position - new Vector3(0f, 0.2f, 0f), false);
        light.intensity = 10f;
        return (lightModel, light);
    }

    public void RenderAllModels(Camera camera, Light light)
    {
        foreach (var model in worldModels)
        {
            if (model.Material.diffuse != Vector3.Zero)
            {
                model.Draw(camera, light);
            }
        }
    }

    public void UpdateAllModels(float deltaTime)
    {
        foreach (var model in worldModels)
        {
            if (model.rotationSpeed != 0f)
            {
                model.rotation.Y += model.rotationSpeed * deltaTime;
            }
        }
    }
}
