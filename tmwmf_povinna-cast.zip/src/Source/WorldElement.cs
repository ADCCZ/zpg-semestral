﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace semestral
{
    public enum WorldElement
    {
        Empty,        // Represented by spaces or 'a' to 'n'
        Wall,         // Represented by 'o' to 'z'
        StartPosition, // Represented by '@'
        Light,         // Represented by '*', '^', '!'
        Door,          // Represented by 'A' to 'G'
        Object,        // Represented by 'H' to 'N'
        Enemy,         // Represented by 'O' to 'R'
        Collectible,   // Represented by 'T' to 'Z'
        Custom         // Any other custom characters
    }
}
